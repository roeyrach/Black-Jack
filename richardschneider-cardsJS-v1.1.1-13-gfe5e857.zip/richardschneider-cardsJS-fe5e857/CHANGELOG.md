The [change log](https://github.com/richardschneider/cardsJS/releases) is automatically produced with
the help of [semantic-release](https://github.com/semantic-release/semantic-release).
